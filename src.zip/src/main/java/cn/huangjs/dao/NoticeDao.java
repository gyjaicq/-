package cn.huangjs.dao;

import cn.huangjs.pojo.Notice;

import java.util.List;

public interface NoticeDao {
    List<Notice> selectByCondition(String topic);

    Notice selectById(Integer id);

    int update(Notice notice);

    int deleteByIds(List<Integer> list);

    int addNotice(Notice notice);

    List<Notice> selectNoticeList();
}
