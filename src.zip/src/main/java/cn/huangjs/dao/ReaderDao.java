package cn.huangjs.dao;

import cn.huangjs.pojo.Reader;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ReaderDao {
    List<Reader> selectByCondition(@Param("readerNumber") String readerNumber, @Param("username") String username, @Param("tel") String tel);

    int saveReader(Reader reader);

    Reader getById(Integer id);

    int update(Reader reader);

    int deleteReaders(List<Integer> list);
}
