package cn.huangjs.dao;

import cn.huangjs.pojo.Lend;
import cn.huangjs.pojo.Reader;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface LendDao {
    List<Lend> selectByCondition(@Param("name") String name, @Param("readerNumber") String readerNumber, @Param("status") Integer status);

    Reader selectByReaderNumber(String readerNumber);


    int addLend(Lend lend);

    int deleteByIds(@Param("ids") List<Integer> ids, @Param("bookIds") List<Integer> bookIds);


    int updateBackType(Lend lend);

    Lend selectById(String id);

    int updateLendInfo(Lend lend);

    Lend selectByIdAndBookAndReader(Integer id);

    List<Lend> selectByBookId(Integer id);

    List<Lend> selectByReaderId(Integer id);

    int updateStatus(@Param("status") int status, @Param("id") int id);

    int updateStatusByList(@Param("status") int status, @Param("list") List<Integer> list);
}
