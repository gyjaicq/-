package cn.huangjs.dao;

import cn.huangjs.pojo.TypeInfo;

import java.util.List;

public interface TypeDao {

    List<TypeInfo> getAll(String name);

    int addType(TypeInfo typeInfo);

    TypeInfo selectById(Integer id);

    int update(TypeInfo typeInfo);

    int deleteByIds(List<Integer> list);
}
