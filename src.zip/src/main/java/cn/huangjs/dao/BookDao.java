package cn.huangjs.dao;

import cn.huangjs.pojo.Book;
import cn.huangjs.pojo.TypeInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BookDao {

    List<Book> getBookAll();

    List<TypeInfo> getBookTypes();

    int addBook(Book book);

    Book getById(Integer id);

    Book queryById(Integer id);

    int updateBook(Book book);

    int deleteById(Integer id);

    List<Book> selectByCondition(@Param("name") String name, @Param("isbn") Integer isbn, @Param("typeId") Integer typeId);

    int deleteByIds(List<Integer> list);

    List<Book> selectByConditionAndStatus(@Param("name") String name, @Param("isbn") Integer isbn,@Param("typeId") Integer typeId,@Param("status") int status);
}
