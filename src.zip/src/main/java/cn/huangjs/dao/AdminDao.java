package cn.huangjs.dao;

import cn.huangjs.pojo.Admin;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface AdminDao {

    /*1.查询所有的管理员信息*/
    List<Admin> getAllAdmin();

    /*2.根据用户名和密码搜索用户*/
    Admin getAdminByUserNameAndPassword(@Param("username") String username,@Param("password") String password,@Param("adminType") int adminType);


    /*3.删除管理员*/
    int deleteAdmin(List<Integer> ids);


    /*4.添加一个管理员*/
    int addAdmin(Admin admin);


    /*根据id查询管理员*/
    Admin findAdminById(int id);


    /*5.修改管理员密码*/
    int updateAdminPassword(@Param("id") int id,@Param("newpassword") String newPassword);


    /*6.搜索符合条件的用户（用户名，类型)*/
    List<Admin> searchAdmin(@Param("username") String username,@Param("adminType") Integer adminType);
}
