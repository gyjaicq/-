package cn.huangjs.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Lend {
    private Integer id;
    private Integer bookId;
    private Integer readerId;
    private Date lendDate;
    private Date backDate;
    private Integer backType;
    private String exceptRemarks;

    private Book book;
    private Reader reader;
}
