package cn.huangjs.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Reader {
    private Integer id;
    private String username;
    private String password;
    private String realName;
    private String sex;
    private Date birthday;
    private String address;
    private String tel;
    private String email;
    private Date registerDate;
    private String readerNumber;
}
