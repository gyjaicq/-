package cn.huangjs.service;

import cn.huangjs.dao.BookDao;
import cn.huangjs.pojo.Book;
import cn.huangjs.pojo.TypeInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookDao bookDao;

    // 查询所有图书信息
    public List<Book> getAllBook() {
        return bookDao.getBookAll();
    }

    // 查询图书类型
    public List<TypeInfo> findAllList() {
        List<TypeInfo> list = bookDao.getBookTypes();
        return list;
    }

    // 添加图书信息
    public boolean addBook(Book book) {
        int count = bookDao.addBook(book);
        if (count > 0) {
            return true;
        }
        return false;
    }

    // 根据id查询图书信息
    public Book getBookById(Integer id) {
        return bookDao.getById(id);
    }

    public Book queryBookInfoById(Integer id) {
        Book book = bookDao.queryById(id);
        return book;
    }

    // 修改图书信息
    public boolean updateBook(Book book) {
        int flag = bookDao.updateBook(book);
        if (flag > 0) {
            return true;
        }
        return false;
    }

    public boolean deleteById(Integer id) {
        int flag = bookDao.deleteById(id);
        if (flag > 0) {
            return true;
        }
        return false;
    }


    public List<Book> selectBooksByCondition(String name, Integer isbn, Integer typeId) {
        return bookDao.selectByCondition(name, isbn, typeId);
    }

    public boolean deleteByIds(String[] ids) {
        List<Integer> list = new ArrayList<>();
        for (String id : ids) {
            list.add(Integer.parseInt(id));
        }
        int flag = bookDao.deleteByIds(list);

        if (flag == 0) {
            return false;
        }
        return true;
    }

    public List<Book> selectBooksByConditionAndStatus(String name, Integer isbn, Integer typeId, int status) {
        return bookDao.selectByConditionAndStatus(name, isbn, typeId, status);
    }
}
