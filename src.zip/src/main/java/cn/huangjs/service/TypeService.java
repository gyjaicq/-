package cn.huangjs.service;

import cn.huangjs.dao.TypeDao;
import cn.huangjs.pojo.TypeInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TypeService {
    @Autowired
    private TypeDao typeDao;


    public List<TypeInfo> getTypeAll(String name) {
        return typeDao.getAll(name);
    }

    public boolean addType(TypeInfo typeInfo) {
        int flag = typeDao.addType(typeInfo);
        if (flag == 0) {
            return false;
        }
        return true;
    }

    public TypeInfo selectById(Integer id) {
        return typeDao.selectById(id);
    }

    public boolean updateType(TypeInfo typeInfo) {
        int flag = typeDao.update(typeInfo);
        if (flag == 0) {
            return false;
        }
        return true;
    }

    public boolean deleteType(String[] ids) {
        List<Integer> list = new ArrayList<>();
        for (String id : ids) {
            list.add(Integer.parseInt(id));
        }
        int flag = typeDao.deleteByIds(list);
        if (flag > 0) {
            return true;
        }
        return false;
    }
}
