package cn.huangjs.service;

import cn.huangjs.dao.ReaderDao;
import cn.huangjs.pojo.Reader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReaderService {

    @Autowired
    private ReaderDao readerDao;

    /**
     * 根据条件查询所有读者信息
     * @param readerNumber
     * @param username
     * @param tel
     * @return
     */
    public List<Reader> selectReadersByCondition(String readerNumber, String username, String tel) {
        return readerDao.selectByCondition(readerNumber, username, tel);
    }

    public boolean addReader(Reader reader) {
        int flag = readerDao.saveReader(reader);
        if (flag == 0) {
            return false;
        }
        return true;
    }

    public Reader queryReaderInfoById(Integer id) {
        return readerDao.getById(id);
    }

    public boolean updateReader(Reader reader) {
        int flag = readerDao.update(reader);

        if (flag == 0) {
            return false;
        }
        return true;
    }


    public boolean deleteReaders(String[] ids) {
        List<Integer> list = new ArrayList<>();
        for (String id : ids) {
            list.add(Integer.parseInt(id));
        }
        int flag = readerDao.deleteReaders(list);
        if (flag == 0) {
            return false;
        }
        return true;
    }
}
