package cn.huangjs.service;


import cn.huangjs.dao.AdminDao;
import cn.huangjs.pojo.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    @Autowired
    AdminDao adminDao;

    /*1.获取管理员列表*/
    public List<Admin> getAllAdmin() {
        /*调用了adminDao内的获取所有管理员的方法*/
        return adminDao.getAllAdmin();
    }


    /*2.验证登录*/
    public boolean checkLogin(String username, String password, int adminType) {
        //1.根据用户名和密码、类型查询管理员
        Admin admin = adminDao.getAdminByUserNameAndPassword(username, password, adminType);

        //2.判断查询出来的admin是否存在
        if (admin != null) {
            //说明登录成功
            return true;
        } else {
            return false;
        }
    }

    /*3.删除管理员*/
    public boolean deleteAdmin(List<Integer> ids) {
        int result = adminDao.deleteAdmin(ids);

        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }


    /*4.添加一个管理员*/
    public boolean addAdmin(Admin admin) {
        int result = adminDao.addAdmin(admin);

        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    /*根据id查询管理员*/
    public Admin getAdminById(int id) {
        return adminDao.findAdminById(id);
    }


    /*5.修改密码*/
    public boolean updateAdminPassword(int id, String newPassword) {
        if (adminDao.updateAdminPassword(id, newPassword) > 0) {
            return true;
        } else {
            return false;
        }
    }


    /*6.条件搜索管理员*/
    public List<Admin> searchAdmin(String username, Integer adminType) {
        return adminDao.searchAdmin(username, adminType);
    }
}
