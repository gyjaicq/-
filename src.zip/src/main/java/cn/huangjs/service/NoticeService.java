package cn.huangjs.service;

import cn.huangjs.dao.NoticeDao;
import cn.huangjs.pojo.Notice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class NoticeService {

    @Autowired
    private NoticeDao noticeDao;

    public List<Notice> selectByCondition(String topic) {
        return noticeDao.selectByCondition(topic);
    }

    public Notice selectById(Integer id) {
        return noticeDao.selectById(id);
    }

    public boolean updateNotice(Notice notice) {
        int flag = noticeDao.update(notice);
        if (flag == 0) {
            return false;
        }
        return true;
    }

    public int deleteByIds(String[] ids) {
        List<Integer> list = new ArrayList<>();
        for (String id : ids) {
            list.add(Integer.parseInt(id));
        }
        return noticeDao.deleteByIds(list);
    }

    public int addNotice(Notice notice, String username) {
        notice.setAuthor(username);
        return noticeDao.addNotice(notice);
    }

    public List<Notice> selectNoticeList() {
        return noticeDao.selectNoticeList();
    }
}
