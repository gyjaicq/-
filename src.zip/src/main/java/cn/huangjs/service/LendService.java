package cn.huangjs.service;

import cn.huangjs.pojo.Lend;
import cn.huangjs.pojo.Reader;
import cn.huangjs.dao.LendDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class LendService {

    @Autowired
    private LendDao lendDao;


    public List<Lend> selectByCondition(String name, String readerNumber, Integer status) {
        return lendDao.selectByCondition(name, readerNumber, status);
    }

    public boolean addLend(String readerNumber, String[] ids) {
        Lend lend = new Lend();
        // 1. 根据readerNumber去reader_info表中查询是否有该借书卡
        Reader reader = lendDao.selectByReaderNumber(readerNumber);
        if (reader != null) {
            // 该借书卡存在,存储reader中的id和book_id和当前时间（借书时间）
            Integer rid = reader.getId();
            for (String id : ids) {
                Integer bid = Integer.parseInt(id);
                long time = System.currentTimeMillis();
                Date date = new Date(time);
                lend.setLendDate(date);
                lend.setBookId(bid);
                lend.setReaderId(rid);
                lend.setBackType(4);
                int count = lendDao.addLend(lend);
            }
            return true;
        } else {
            // 借书卡不存在，返回false
            return false;
        }
    }

    public int deleteByIdsAndBookIds(String[] Ids, String[] BookIds) {
        List<Integer> ids = new ArrayList<>();
        List<Integer> bookIds = new ArrayList<>();
        for (String id : Ids) {
            ids.add(Integer.parseInt(id));
        }
        for (String bookId : BookIds) {
            bookIds.add(Integer.parseInt(bookId));
        }
        return lendDao.deleteByIds(ids, bookIds);
    }

    public int updateBackTypeByIdsAndBookIds(String[] Ids, String[] BookIds, Integer backType) {
        Integer count = 0;
        Lend lend = new Lend();
        List<Integer> ids = new ArrayList<>();
        List<Integer> bookIds = new ArrayList<>();
        for (String bookId : BookIds) {
            bookIds.add(Integer.parseInt(bookId));
        }
        for (String id : Ids) {
            long time = System.currentTimeMillis();
            Date date = new Date(time);
            lend.setBackDate(date);
            lend.setId(Integer.parseInt(id));
            lend.setBackType(backType);
            count += lendDao.updateBackType(lend);
        }
        return count;
    }

    public Lend selectById(String id) {
        return lendDao.selectById(id);
    }

    public int updateLendInfo(Integer id, Integer backType, String remarks) {
        Lend lend = new Lend();
        lend.setBackType(backType);
        lend.setId(id);
        lend.setExceptRemarks(remarks);
        long time = System.currentTimeMillis();
        Date date = new Date(time);
        lend.setBackDate(date);
        return lendDao.updateLendInfo(lend);
    }

    public Lend selectByIdAndBookAndReader(Integer id) {
        return lendDao.selectByIdAndBookAndReader(id);
    }

    public List<Lend> selectByBookId(Integer id) {
        return lendDao.selectByBookId(id);
    }

    public List<Lend> selectByReaderId(Integer id) {
        return lendDao.selectByReaderId(id);
    }

    public int updateStatus(int status, int id) {
        return lendDao.updateStatus(status, id);
    }

    public int updateStatusByList(int status, String[] ids) {
        List<Integer> list = new ArrayList<>();
        for (String id : ids) {
            list.add(Integer.parseInt(id));
        }
        return lendDao.updateStatusByList(status, list);
    }
}
