package cn.huangjs.controller.type;

import cn.huangjs.service.TypeService;
import cn.huangjs.pojo.TypeInfo;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ResponseBody
@Controller
public class TypeController {

    @Autowired
    private TypeService typeService;

    /**
     * 类型信息添加
     *
     * @param typeInfo
     * @return
     */
    @RequestMapping("addTypeSubmit")
    public Map<String, Object> addType(TypeInfo typeInfo) {
        Map<String, Object> map = new HashMap<>();

        boolean flag = typeService.addType(typeInfo);

        map.put("flag", flag);
        map.put("code", 0);
        map.put("msg", "");
        return map;

    }


    /**
     * 根据条件进行查询
     *
     * @param page
     * @param limit
     * @param name
     * @return
     */
    @RequestMapping("typeAll")
    public Map<String, Object> typeAll(Integer page, Integer limit, String name) {
        Map<String, Object> map = new HashMap<>();

        if (name == null) {
            name = "";
        }

        PageHelper.startPage(page, limit);
        List<TypeInfo> list = typeService.getTypeAll(name);
        PageInfo<TypeInfo> pageInfo = new PageInfo<>(list);

        map.put("code", 0);
        map.put("msg", "");
        map.put("data", pageInfo.getList());
        map.put("count", pageInfo.getTotal());
        return map;
    }

    /**
     * 修改类型信息
     * @param typeInfo
     * @return
     */
    @RequestMapping("updateTypeSubmit")
    public Map<String, Object> updateType(@RequestBody TypeInfo typeInfo) {
        Map<String, Object> map = new HashMap<>();

        boolean flag = typeService.updateType(typeInfo);

        System.out.println("typeInfo = " + typeInfo);

        if (flag) {
            map.put("code", 0);
        } else {
            map.put("code", -1);
        }
        map.put("msg", "");
        return map;
    }

    @RequestMapping("deleteType")
    public Map<String, Object> deleteType(String ids) {
        Map<String, Object> map = new HashMap<>();

        String[] Ids = ids.split(",");
        boolean flag = typeService.deleteType(Ids);


        if (flag) {
            map.put("code", 0);
        } else {
            map.put("code", -1);
        }
        map.put("msg", "");
        return map;
    }




}
