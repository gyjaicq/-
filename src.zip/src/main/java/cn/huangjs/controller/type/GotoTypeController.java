package cn.huangjs.controller.type;


import cn.huangjs.pojo.TypeInfo;
import cn.huangjs.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GotoTypeController {

    @Autowired
    private TypeService typeService;

    // 访问类型管理界面
    @RequestMapping("typeIndex")
    public String typeIndex() {
        return "type/typeIndex";
    }

    // 访问类型管理添加页面
    @RequestMapping("typeAdd")
    public String typeAdd() {
        return "type/typeAdd";
    }

    // 访问类型管理修改页面
    @RequestMapping("queryTypeInfoById")
    public String queryTypeInfoById(Integer id, Model model) {
        TypeInfo typeInfo = typeService.selectById(id);
        model.addAttribute("info", typeInfo);
        return "type/updateType";
    }



}
