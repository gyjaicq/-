package cn.huangjs.controller.reader;

import cn.huangjs.pojo.Reader;
import cn.huangjs.service.ReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GotoReaderController {

    @Autowired
    private ReaderService readerService;

    // 访问读者管理页面
    @RequestMapping("readerIndex")
    public String readerIndex() {
        return "reader/readerIndex";
    }

    // 访问读者添加页面
    @RequestMapping("readerAdd")
    public String readerAdd() {
        return "reader/readerAdd";
    }

    // 访问读者修改页面
    @RequestMapping("queryReaderInfoById")
    public String updateReader(Integer id, Model model) {
        Reader reader = readerService.queryReaderInfoById(id);
        model.addAttribute("info", reader);
        return "reader/updateReader";
    }

}
