package cn.huangjs.controller.reader;


import cn.huangjs.pojo.Reader;
import cn.huangjs.service.ReaderService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ResponseBody
@Controller
public class ReaderController {

    @Autowired
    private ReaderService readerService;

//  删除功能
    @RequestMapping("deleteReaders")
    public Map<String, Object> deleteReaders(String ids) {
        Map<String, Object> map = new HashMap<>();

        // 分隔字符串
        String[] Ids = ids.split(",");
        boolean flag = readerService.deleteReaders(Ids);

        map.put("flag", flag);
        map.put("code", 0);
        map.put("msg", "");
        return map;
    }


    /**
     * 根据id修改读者信息
     * @param reader
     * @return
     */
    @RequestMapping("updateReaderSubmit")
    public Map<String, Object> updateReader(@RequestBody Reader reader) {
        Map<String, Object> map = new HashMap<>();

        boolean flag = readerService.updateReader(reader);

        map.put("flag", flag);
        map.put("code", 0);
        map.put("msg", "");
        return map;
    }


    /**
     * 将读者信息添加功能
     * @param reader
     * @return
     */
    @RequestMapping("addReaderSubmit")
    public Map<String, Object> addReader(@RequestBody Reader reader) {
        Map<String, Object> map = new HashMap<>();

        System.out.println("reader = " + reader);

        boolean flag = readerService.addReader(reader);

        map.put("flag", flag);
        map.put("code", 0);
        map.put("msg", "");
        return map;
    }

    /**
     * 根据条件查询所有读者信息
     * @param page
     * @param limit
     * @param readerNumber
     * @param username
     * @param tel
     * @return
     */
    @RequestMapping("readerAll")
    public Map<String, Object> readAll(Integer page, Integer limit, String readerNumber, String username, String tel) {
        Map<String, Object> map = new HashMap<>();
        if (readerNumber == null) {
            readerNumber = "";
        }
        if (username == null) {
            username = "";
        }
        if (tel == null) {
            tel = "";
        }
        PageHelper.startPage(page, limit);
        List<Reader> readerList = readerService.selectReadersByCondition(readerNumber, username, tel);
        PageInfo<Reader> pageInfo = new PageInfo<>(readerList);
        map.put("code", 0);
        map.put("msg", "");
        /*count表示数据的总条数*/
        map.put("count", pageInfo.getTotal());
        map.put("data", pageInfo.getList());
        return map;
    }

}
