package cn.huangjs.controller.lend;

import cn.huangjs.pojo.Lend;
import cn.huangjs.service.LendService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ResponseBody
@Controller
public class LendController {

    @Autowired
    private LendService lendService;

    /**
     * 根据id修改借阅管理的异常还书信息
     *
     * @param id
     * @param bookId
     * @param backType
     * @param remarks
     * @return
     */
    @RequestMapping("updateLendInfoSubmit")
    public Map<String, Object> updateLendInfo(Integer id, Integer bookId, Integer backType, String remarks) {
        Map<String, Object> map = new HashMap<>();

        int count = lendService.updateLendInfo(id, backType, remarks);

        if (backType == 0 || backType == 1 || backType == 2) {
            // 还书设置reader_info表里的status值
            int status = 0;// 0表示未借出，1表示已借出
            int flag = lendService.updateStatus(status, bookId);
        }

        if (count == 0) {
            map.put("code", -1);
        } else {
            map.put("code", 0);
        }

        return map;
    }


    /**
     * 根据id还书（正常还书）
     * 1. 查询该id对应的书是否已归还
     *
     * @param ids
     * @param bookIds
     * @return
     */
    @RequestMapping("backLendListByIds")
    public Map<String, Object> backLendListByIds(String ids, String bookIds) {
        Map<String, Object> map = new HashMap<>();
        // 正常还书
        Integer backType = 0;
        String[] Ids = ids.split(",");
        String[] BookIds = bookIds.split(",");
        // 判断backType类型，如果backType=4时，属于在借中，则可以还书
        for (String id : Ids) {
            Lend lend = lendService.selectById(id);
            if (lend.getBackType() != 4 && lend.getBackType() != 3) {
                //该书已还，返回失败
                map.put("code", -1);
                map.put("msg", "");
                return map;
            }
        }// 还书设置lend_list表里的值
        int count = lendService.updateBackTypeByIdsAndBookIds(Ids, BookIds, backType);
        // 还书设置reader_info表里的status值
        int status = 0;// 0表示未借出，1表示已借出
        int flag = lendService.updateStatusByList(status, BookIds);
        if (count == 0) {
            map.put("code", -1); }
            else {
            map.put("code", 0); }
        return map;
    }


    /**
     * 借书功能
     *
     * @param readerNumber
     * @param ids
     * @return
     */
    @RequestMapping("addLend")
    public Map<String, Object> addLend(String readerNumber, String ids) {
        Map<String, Object> map = new HashMap<>();
        String[] Ids = ids.split(",");
        boolean flag = lendService.addLend(readerNumber, Ids);
        // 借书后更新status的值为1，是借书状态
        int status = 1;
        for (String id : Ids) {
            int i = lendService.updateStatus(status, Integer.parseInt(id));
        }
        if (!flag) {
            map.put("code", -1);
            map.put("msg", "未查询到该借书卡！！！");
        } else {
            map.put("code", 0);
            map.put("msg", "");
        }
        return map;
    }


    /**
     * 根据条件进行查询
     *
     * @param page
     * @param limit
     * @param name
     * @param readerNumber
     * @param status
     * @return
     */
    @RequestMapping("lendListAll")
    public Map<String, Object> lendListAll(Integer page, Integer limit, String name, String readerNumber, Integer status) {
        Map<String, Object> map = new HashMap<>();

        if (name == null) {
            name = "";
        }
        if (readerNumber == null) {
            readerNumber = "";
        }
        PageHelper.startPage(page, limit);
        List<Lend> list = lendService.selectByCondition(name, readerNumber, status);
        PageInfo<Lend> pageInfo = new PageInfo<>(list);

        map.put("data", pageInfo.getList());
        map.put("count", pageInfo.getTotal());
        map.put("code", 0);
        map.put("msg", "");
        return map;
    }

    /**
     * 根据id批量删除借阅信息
     *
     * @param ids
     * @param bookIds
     * @return
     */
    @RequestMapping("deleteLendListByIds")
    public Map<String, Object> deleteLendListByIds(String ids, String bookIds) {
        Map<String, Object> map = new HashMap<>();

        String[] Ids = ids.split(",");
        String[] BookIds = bookIds.split(",");
        int flag = lendService.deleteByIdsAndBookIds(Ids, BookIds);

        if (flag == 0) {
            map.put("code", -1);
        } else {
            map.put("code", 0);
        }
        map.put("msg", "");
        return map;
    }

}
