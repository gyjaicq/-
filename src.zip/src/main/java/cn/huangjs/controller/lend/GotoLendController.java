package cn.huangjs.controller.lend;

import cn.huangjs.pojo.Lend;
import cn.huangjs.service.LendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class GotoLendController {

    @Autowired
    private LendService lendService;

    // 访问借阅管理界面
    @RequestMapping("lendListIndex")
    public String lendListIndex() {
        return "lend/lendListIndex";
    }

    // 访问借阅管理添加页面
    @RequestMapping("addLendList")
    public String addLendList() {
        return "lend/addLendList";
    }

    //访问借阅管理异常还书页面
    @RequestMapping("excBackBook")
    public String excBackBook(Integer id, Integer bookId, HttpServletRequest request) {
        System.out.println("------------------");
        System.out.println("id = " + id);
        System.out.println("bookId = " + bookId);
        System.out.println("------------------");
        request.setAttribute("id", id);
        request.setAttribute("bid", bookId);
        return "lend/excBackBook";
    }

    // 访问借阅管理时间线页面
    @RequestMapping("queryLookBookList")
    public String queryLookBookList(Integer id, String flag, Model model) {
        List<Lend> list = null;
        // 该id为bookId，根据id查询该图书被借阅的所有借阅人
        if (flag.equals("book")) {
            list = lendService.selectByBookId(id);
        }
        // 该id为readerId，根据id查询该id所借阅的所有图书
        if (flag.equals("user")) {
            list = lendService.selectByReaderId(id);
        }
        model.addAttribute("info", list);
        return "lend/lookBookList";
    }
}
