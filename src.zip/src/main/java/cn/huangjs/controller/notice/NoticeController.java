package cn.huangjs.controller.notice;

import cn.huangjs.service.NoticeService;
import cn.huangjs.pojo.Notice;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ResponseBody
@Controller
public class NoticeController {

    @Autowired
    private NoticeService noticeService;

    @RequestMapping("addNoticeSubmit")
    public Map<String, Object> addNotice(Notice notice, HttpServletRequest request) {
        Map<String, Object> map = new HashMap<>();

        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        int flag = noticeService.addNotice(notice, username);

        if (flag == 0) {
            map.put("code", -1);
        } else {
            map.put("code", 0);
        }
        map.put("msg", "");
        return map;

    }

    /**
     * 根据id批量删除
     *
     * @param ids
     * @return
     */
    @RequestMapping("deleteNoticeByIds")
    public Map<String, Object> deleteNoticeByIds(String ids) {
        Map<String, Object> map = new HashMap<>();

        String[] Ids = ids.split(",");
        int flag = noticeService.deleteByIds(Ids);

        if (flag == 0) {
            map.put("code", -1);
        } else {
            map.put("code", 0);
        }
        map.put("msg", "");
        return map;

    }

    /**
     * 修改公告信息
     *
     * @param notice
     * @return
     */
    @RequestMapping("updateNoticeSubmit")
    public Map<String, Object> updateNotice(@RequestBody Notice notice) {
        Map<String, Object> map = new HashMap<>();

        boolean flag = noticeService.updateNotice(notice);

        if (flag) {
            map.put("code", 0);
        } else {
            map.put("code", -1);
        }
        map.put("msg", "");
        return map;

    }

    /**
     * 根据条件查询公告信息
     *
     * @param page
     * @param limit
     * @param topic
     * @return
     */
    @RequestMapping("noticeAll")
    public Map<String, Object> noticeAll(Integer page, Integer limit, String topic) {
        Map<String, Object> map = new HashMap<>();

        System.out.println("topic = " + topic);

        if (topic == null) {
            topic = "";
        }

        PageHelper.startPage(page, limit);
        List<Notice> list = noticeService.selectByCondition(topic);
        PageInfo<Notice> pageInfo = new PageInfo<>(list);

        map.put("data", pageInfo.getList());
        map.put("count", pageInfo.getTotal());
        map.put("code", 0);
        map.put("msg", "");
        return map;
    }


}
