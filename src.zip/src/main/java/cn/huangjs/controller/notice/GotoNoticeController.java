package cn.huangjs.controller.notice;

import cn.huangjs.pojo.Notice;
import cn.huangjs.service.NoticeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GotoNoticeController {

    @Autowired
    private NoticeService noticeService;

    // 访问公告管理页面
    @RequestMapping("noticeIndexOfBack")
    public String noticeIndexOfBack() {
        return "notice/noticeIndexOfBack";
    }

    // 访问公告管理修改页面
    @RequestMapping("queryNoticeById")
    public String queryNoticeById(Integer id, Model model) {
        Notice notice = noticeService.selectById(id);
        model.addAttribute("info", notice);
        return "/notice/updateNotice";
    }

    // 访问公告管理添加页面
    @RequestMapping("noticeAdd")
    public String noticeAdd() {
        return "/notice/noticeAdd";
    }

}
