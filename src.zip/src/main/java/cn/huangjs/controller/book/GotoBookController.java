package cn.huangjs.controller.book;

import cn.huangjs.pojo.Book;
import cn.huangjs.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GotoBookController {

    @Autowired
    private BookService bookService;


    // 访问图书管理添加页面
    @RequestMapping("/bookAdd")
    public String bookAdd() {
        return "/book/bookAdd";
    }

    //根据id查询图书信息，然后访问图书信息修改页面
    @RequestMapping("/queryBookInfoById")
    public String updateBook(Integer id, Model model) {
        Book book = bookService.getBookById(id);
        model.addAttribute("info", book);
        return "/book/updateBook";
    }


    // 访问图书管理页面
    @RequestMapping("/bookIndex")
    public String bookIndex() {
        return "/book/bookIndex";
    }


}
