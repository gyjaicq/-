package cn.huangjs.controller.book;

import cn.huangjs.pojo.Book;
import cn.huangjs.pojo.TypeInfo;
import cn.huangjs.service.BookService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ResponseBody
@Controller
public class BookController {

    @Autowired
    private BookService bookService;

    /**
     * 根据id批量删除
     * @param ids
     * @return
     */
    @RequestMapping("deleteBooks")
    public Map<String, Object> deleteBook(String ids) {
        Map<String, Object> map = new HashMap<>();

        String[] IDS = ids.split(",");

        for (String id : IDS) {
            System.out.print(id);
        }

        boolean flag = bookService.deleteByIds(IDS);

//        boolean flag = bookService.deleteById(ids);

        map.put("code", 0);
        map.put("msg", "");
        return map;
    }


    /**
     * 修改图书信息
     * @param book
     * @return
     */
    @RequestMapping("updateBookSubmit")
    public Map<String, Object> updateBookSubmit(@RequestBody Book book) {
        Map<String, Object> map = new HashMap<>();

        System.out.println("book = " + book);

        boolean flag = bookService.updateBook(book);

        System.out.println("flag = " + flag);

        if (flag) {
            map.put("code", 0);
            map.put("msg", "");
        } else {
            map.put("code", -1);
            map.put("msg", "");
        }
        return map;
    }


    /**
     * 添加图书信息
     *
     * @param book
     * @return
     */
    @RequestMapping("/addBook")
    public Map<String, Object> addBook(Book book) {

        System.out.println("-------------------");
        System.out.println("/addBook被请求......");
        System.out.println("book = " + book);
        System.out.println("-------------------");

        Map<String, Object> map = new HashMap<>();
        boolean flag = bookService.addBook(book);

        if (flag) {
            map.put("code", 0);
        } else {
            map.put("code", -1);
        }
        map.put("msg", "");

        return map;
    }


    /**
     * 查询图书数据类型
     *
     * @return
     */
    @RequestMapping("/findAllList")
    public Map<String, Object> findAllList() {
        Map<String, Object> map = new HashMap<>();
        List<TypeInfo> typeInfos = bookService.findAllList();

        map.put("code", 0);
        map.put("msg", "");
        map.put("data", typeInfos);

        return map;
    }



    /**
     * 根据条件查询全部图书信息
     * @param page   当前页面
     * @param limit  当前页面显示条数
     * @param name   查询条件姓名 name
     * @param isbn   查询条件图书编号 isbn
     * @param typeId 查询条件图书类型 typeId
     * @return
     */
    @RequestMapping("bookAll")
    public Map<String, Object> bookAll(Integer page, Integer limit, String name, Integer isbn, Integer typeId) {
        Map<String, Object> map = new HashMap<>();
        if (name == null) {
            name = "";
        }
        PageHelper.startPage(page, limit);
        List<Book> bookList = bookService.selectBooksByCondition(name, isbn, typeId);
        PageInfo<Book> pageInfo = new PageInfo<>(bookList);
        map.put("code", 0);
        map.put("msg", "");
        // count表示数据的总条数
        map.put("count", pageInfo.getTotal());
        map.put("data", pageInfo.getList());
        return map;
    }

    @RequestMapping("bookAllByStatus")
    public Map<String, Object> bookAllByStatus(Integer page, Integer limit, String name, Integer isbn, Integer typeId) {
        Map<String, Object> map = new HashMap<>();

        if (name == null) {
            name = "";
        }

        //设置status的值为0，为后面查询未借出的书
        int status = 0;

        // 该处查询不需要有limit的限制
        limit = 10000;

        PageHelper.startPage(page, limit);
        List<Book> bookList = bookService.selectBooksByConditionAndStatus(name, isbn, typeId, status);
        PageInfo<Book> pageInfo = new PageInfo<>(bookList);

        map.put("code", 0);
        map.put("msg", "");
        // count表示数据的总条数
        map.put("count", pageInfo.getTotal());
        map.put("data", pageInfo.getList());

        return map;
    }




}
