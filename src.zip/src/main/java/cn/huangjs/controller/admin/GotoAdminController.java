package cn.huangjs.controller.admin;

import cn.huangjs.pojo.Notice;
import cn.huangjs.service.AdminService;
import cn.huangjs.service.NoticeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class GotoAdminController {

    @Autowired
    AdminService adminService;

    @Autowired
    NoticeService noticeService;

    /*访问欢迎页面*/
    @RequestMapping("/welcome")
    public String welcome(Model model) {
        List<Notice> noticeList = noticeService.selectNoticeList();
        model.addAttribute("noticeList", noticeList);

        return "welcome";
    }

    /*访问管理员管理页面*/
    @RequestMapping("/adminIndex")
    public String adminIndex() {
        return "/admin/adminIndex";
    }


    /*访问添加管理员的页面*/
    @RequestMapping("/adminAdd")
    public String adminAdd() {
        return "/admin/adminAdd";
    }

    /*访问修改管理员信息页面*/
    @RequestMapping("/toUpdateAdmin")
    public String toUpdateAdmin(int id, Model model) {
        model.addAttribute("nowAdmin", adminService.getAdminById(id));
        return "/admin/updateAdmin";
    }
}
