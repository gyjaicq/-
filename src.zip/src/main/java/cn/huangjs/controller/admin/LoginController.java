package cn.huangjs.controller.admin;

import cn.huangjs.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    @Autowired
    AdminService adminService;


    /*验证登录*/
    @RequestMapping("/checkLogin")
    public String checkLogin(Model model, String username, String password, Integer adminType, HttpServletRequest request) {

        HttpSession session = request.getSession();
        session.removeAttribute("username");

//        // 点击首页的图书管理图标时会发送一次checkLogin请求，adminType值为null，设置跳转404.jsp页面
        if (adminType == null) {
            return "404";
        }

        /*1.调用adminservice里面验证登录的方法*/
        boolean result = adminService.checkLogin(username, password, adminType);

        /*2.判断result*/
        if (result == true) {
            session.setAttribute("username", username);
            session.setAttribute("password", password);
            session.setAttribute("adminType", adminType);
            System.out.println("username = " + username);
            System.out.println("password = " + password);
            System.out.println("adminType = " + adminType);
            return "index";
        } else {
            model.addAttribute("tips", "用户名、密码、类型填写错误！！");
            return "login";
        }
    }


}
