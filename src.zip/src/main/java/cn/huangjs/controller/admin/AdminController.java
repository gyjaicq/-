package cn.huangjs.controller.admin;

import cn.huangjs.pojo.Admin;
import cn.huangjs.service.AdminService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

@Controller
public class AdminController {

    @Autowired
    AdminService adminService;

    /*1.返回测试页面，展示管理员列表*/
    @RequestMapping("/toTest")
    public String toTest(Model model) {

        List<Admin> adminList = adminService.getAllAdmin();

        model.addAttribute("adminList", adminList);
        return "test";
    }


    /*2.adminIndex页面请求过来，返回管理员列表*/
    @ResponseBody
    @RequestMapping("/adminAll")
    public Map<String, Object> adminAll(int page, int limit) {
        Map<String, Object> map = new HashMap<>();

        PageHelper.startPage(page, limit);
        List<Admin> adminList = adminService.getAllAdmin();

        PageInfo<Admin> pageInfo = new PageInfo<>(adminList);

        map.put("code", 0);
        map.put("msg", "");
        /*count表示数据的总条数*/
        map.put("count", pageInfo.getTotal());
        map.put("data", pageInfo.getList());
        return map;
    }


    /*3.删除*/
    @ResponseBody
    @RequestMapping("/deleteAdminByIds")
    public Map<String, Object> deleteAdmin(String ids) {
        Map<String, Object> map = new HashMap<>();

        //将字符串，转化为集合
        List<String> idstrList = Arrays.asList(ids.split(","));

        //将集合内的id的类型转化为整数
        List<Integer> idList = new ArrayList<>();
        for (String idstr : idstrList) {
            idList.add(Integer.parseInt(idstr));
        }

        if (adminService.deleteAdmin(idList)) {
            //如果删除成功，返回0
            map.put("code", 0);
        } else {
            map.put("code", -1);
        }

        return map;
    }


    /*4.添加*/
    @ResponseBody
    @RequestMapping("/addAdmin")
    public Map<String, Object> addAdmin(Admin admin) {
        Map<String, Object> map = new HashMap<>();

        if (adminService.addAdmin(admin) == true) {
            map.put("code", 0);
        } else {
            //返回-1表示添加失败
            map.put("code", -1);
        }
        return map;
    }


    /*5.修改密码*/
    @ResponseBody
    @RequestMapping("/updatePassword")
    public Map<String, Object> updatePassword(int id, String newPwd) {
        Map<String, Object> map = new HashMap<>();

        if (adminService.updateAdminPassword(id, newPwd) == true) {
            map.put("code", 0);
        } else {
            map.put("code", -1);
        }
        return map;
    }


    /*6.条件搜索用户*/
    @ResponseBody
    @RequestMapping("/searchAdmin")
    public Map<String, Object> searchAdmin(String username, Integer adminType) {
        Map<String, Object> map = new HashMap<>();

        /*对数据进行判断空值处理*/
        if (username.trim().length() == 0) {
            username = null;
        }
        if (adminType == -1) {
            adminType = null;
        }

        List<Admin> adminList = adminService.searchAdmin(username, adminType);

        map.put("code", 0);
        map.put("msg", "");
        map.put("count", adminList.size());
        map.put("data", adminList);
        return map;

    }

}
