package cn.huangjs.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testReaderService {

    @Autowired
    private ReaderService readerService;

    @Test
    public void test() {
        String[] ids = {"4", "5", "6", "7", "8"};
        boolean flag = readerService.deleteReaders(ids);
        System.out.println("flag = " + flag);
    }

}
