package cn.huangjs.service;

import cn.huangjs.pojo.Notice;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testNoticeService {

    @Autowired
    private NoticeService noticeService;

    @Test
    public void testUpdate() {
        List<Notice> list = noticeService.selectByCondition(null);
        for (Notice notice : list) {
            System.out.println("notice = " + notice);
        }
    }

    @Test
    public void testSelectNoticeList() {
        List<Notice> noticeList = noticeService.selectNoticeList();
        for (Notice notice : noticeList) {
            System.out.println("notice = " + notice);
        }
    }

}
