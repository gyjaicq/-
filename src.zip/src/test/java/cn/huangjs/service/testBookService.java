package cn.huangjs.service;


import cn.huangjs.pojo.Book;
import cn.huangjs.pojo.TypeInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.sql.Date;
import java.util.List;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testBookService {

    @Autowired
    private BookService bookService;


    @Test
    public void testSelectByConditionAndStatus() {
        List<Book> bookList = bookService.selectBooksByConditionAndStatus("", null, null, 0);
        for (Book book : bookList) {
            System.out.println("book = " + book);
        }
    }

    @Test
    public void testGetAllBook() {
        List<Book> list = bookService.getAllBook();
        for (Book book : list) {
            System.out.println("book = " + book);
        }
    }

    @Test
    public void testFindAllTypeList() {
        List<TypeInfo> list = bookService.findAllList();
        for (TypeInfo typeInfo : list) {
            System.out.println("typeInfo = " + typeInfo.getName());
        }
    }

    @Test
    public void testAddBook() {
//        Book book = new Book(16, "毛泽东思想和中国特色社会注意理论体系概论", "毛泽东", "中国人民大学出版社", "100023", "毛泽东思想，思想救国", "中文", 59.9, new Date(2000, 3, 5), 1, 0);

//        boolean flag = bookService.addBook(book);
//        System.out.println("flag = " + flag);
    }

    @Test
    public void testGetById() {
        Book book = bookService.getBookById(1);
        System.out.println("book = " + book);
    }

    @Test
    public void testQueryById() {
        Book book = bookService.queryBookInfoById(3);
        System.out.println("book = " + book);
    }

    @Test
    public void testUpdate() {
        Book book = new Book(23, "22222222222", "2222222222", "@2222222222222", "222222222222", "222222222222", "222222222", 2222, new Date(2222, 2, 22), 2, 0, null);

        boolean flag = bookService.updateBook(book);
        System.out.println("flag = " + flag);
    }

    @Test
    public void testDelete() {
        boolean flag = bookService.deleteById(17);
        System.out.println("flag = " + flag);
    }

    @Test
    public void testSelectCondition() {
        List<Book> bookList = bookService.selectBooksByCondition(null, null, null);
        for (Book book : bookList) {
            System.out.println("book = " + book);
        }
    }

    @Test
    public void testDeleteByIds() {
        String[] ids = {"7", "8", "9", "10"};
        boolean flag = bookService.deleteByIds(ids);
        System.out.println("flag = " + flag);
    }

}
