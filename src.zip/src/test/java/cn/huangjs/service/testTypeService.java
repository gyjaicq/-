package cn.huangjs.service;

import cn.huangjs.pojo.TypeInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testTypeService {

    @Autowired
    private TypeService typeService;

    @Test
    public void testUpdate() {
        boolean flag = typeService.updateType(new TypeInfo(10, "7777777", "777777"));
        System.out.println("flag = " + flag);
    }

}
