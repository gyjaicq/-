package cn.huangjs.service;


import cn.huangjs.pojo.Lend;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testLendService {

    @Autowired
    private LendService lendService;

    @Test
    public void test() {
        String[] ids = {"3", "9", "5", "8"};
        boolean flag = lendService.addLend("8120116041", ids);
        System.out.println("flag = " + flag);
    }

    @Test
    public void demo() {
        List<Lend> lends = lendService.selectByBookId(3);
        for (Lend lend : lends) {
            System.out.println("lend = " + lend);
        }
    }

    @Test
    public void demo1() {
        List<Lend> lends = lendService.selectByCondition("", "", null);
        for (Lend lend : lends) {
            System.out.println("lend = " + lend);
        }
    }

    @Test
    public void demo2() {
        int i = lendService.updateStatus(0, 1);
        System.out.println("i = " + i);
    }

    @Test
    public void demo3() {
        String[] ids = {"1", "2"};
        int i = lendService.updateStatusByList(1, ids);
        System.out.println("i = " + i);
    }

}
