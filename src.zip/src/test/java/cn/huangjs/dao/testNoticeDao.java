package cn.huangjs.dao;

import cn.huangjs.pojo.Notice;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testNoticeDao {

    @Autowired
    private NoticeDao noticeDao;

    @Test
    public void test() {
        List<Notice> list = noticeDao.selectByCondition("");
        for (Notice notice : list) {
            System.out.println("notice = " + notice);
        }
    }

}
