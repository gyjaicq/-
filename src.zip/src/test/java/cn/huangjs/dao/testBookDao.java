package cn.huangjs.dao;

import cn.huangjs.pojo.Book;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testBookDao {

    @Autowired
    private BookDao bookDao;

    @Test
    public void test() {
        List<Book> list = bookDao.getBookAll();
        for (Book book : list) {
            System.out.println("book = " + book);
        }
    }

    @Test
    public void testSelectCondition() {
        List<Book> bookList = bookDao.selectByCondition("", null, null);
        for (Book book : bookList) {
            System.out.println("book = " + book);
        }
    }

    @Test
    public void testGetById() {
        Book book = bookDao.getById(1);
        System.out.println("book = " + book);
    }

}
