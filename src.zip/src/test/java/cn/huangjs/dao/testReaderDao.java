package cn.huangjs.dao;

import cn.huangjs.pojo.Reader;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testReaderDao {

    @Autowired
    private ReaderDao readerDao;

    @Test
    public void testGetById() {
        Reader reader = readerDao.getById(2);
        System.out.println("reader = " + reader);
    }

    @Test
    public void testDeleteById() {
        String[] ids = {"4", "5", "6", "7", "8"};

    }

}
