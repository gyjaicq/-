package cn.huangjs.dao;

import cn.huangjs.pojo.Lend;
import cn.huangjs.pojo.Reader;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring_mybatis_config.xml")
public class testLendDao {

    @Autowired
    private LendDao lendDao;

    @Test
    public void demo() {
        List<Lend> lends = lendDao.selectByCondition(null, null, null);
        for (Lend lend : lends) {
            System.out.println("lend = " + lend);
        }
    }

    @Test
    public void test() {
        Reader reader = lendDao.selectByReaderNumber("8120116041");
        System.out.println("reader = " + reader);
    }

    @Test
    public void demo1() {
//        int count = lendDao.addLend(3, 4);
//        System.out.println("count = " + count);
    }

}
