package cn.huangjs;

import org.junit.Test;

public class test {



    @Test
    public void test() {
        String ids = "11,12,13";
        String[] id = ids.split(",");
        for (String s : id) {
            System.out.println("s = " + s);
        }
    }

}
